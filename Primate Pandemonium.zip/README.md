Credits:

- Original Donkey Kong Sprite: https://www.pinterest.com/pin/757871443542234720/  

- Original Emprty Barrel: http://pixelartmaker.com/art/90c554a4c3b21cf 

- Pixel Heart: https://freesvg.org/pixel-heart

- Grass Background: https://www.artstation.com/artwork/EaKzle 

- Tree: FPixelArt%2Fcomments%2Fej9kwp%2Fjust_your_regular_pixel_palm_tree%2F&psig=AOvVaw0bmnx0lTP_tueTpIwZSezY&ust=1683747127794000&source=images&cd=vfe&ved=0CBIQjhxqFwoTCIigoIT96P4CFQAAAAAdAAAAABAI 

- Banana: https://www.nicepng.com/ourpic/u2q8y3u2o0y3t4y3_pixel-clipart-banana-banana-pixel-art-png/

- Title Screen Background: https://wallpaperaccess.com/pixel-forest 

- Gorilla Tag Menu Button: https://thecodex.fandom.com/wiki/Gorilla_(Gorilla_Tag) 

- Fist: https://www.pixilart.com/draw/fist-b945cc6be5 

- Code for setting up GamePanel (first 4 videos): https://www.youtube.com/watch?v=om59cwR7psI&list=PL_QPQmz5C6WUF-pOQDsbsKbaBZqXj4qSq 