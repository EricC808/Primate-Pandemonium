package entity;

import java.awt.image.BufferedImage;
import main.*;

public class Entity {

    //Default monkey values
    public int x, y;
    public int speed;
    public double diagnoalSpeed;
    public int health;
    public int bananCount;

    //Hitbox size
    private int punchHitBox = 33;

    //Holder image
    public BufferedImage image;
    //Monkey directional sprites
    public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2;
    //Fist directional sprites
    public BufferedImage upFist, downFist, rightFist, leftFist;

    //Direction monkey is currently facing
    public String direction;
    //Fist coordinates
    public int fistX, fistY;

    //Changes how often sprite changes
    public int spriteCounter = 0;
    public int spriteNum = 1;

    KeyHandler keyH;

    //Tree
    BananTree tree;

    //Monkey Barrels
    Barrel rBar, gBar, bBar, pBar;

    //Monkey refrences
    rMonkey red;
    bMonkey blue;
    gMonkey green;
    pMonkey purple;

    //transfers keyhandler to this class to access
    public void getKeyHandler(KeyHandler keyH){
        this.keyH = keyH;
    }

    //transfers monkeys to this class to access methods
    public void getMonkeys(rMonkey r, bMonkey b, gMonkey g, pMonkey p) {
        red = r;
        blue = b;
        green = g;
        purple = p;
    }

    //passes in tree so we can view its methods
    public void getBananTree(BananTree tree){
        this.tree = tree;
    }

    //passes in barrel refrences for each monkey to use
    public void getBarrel(Barrel rBar, Barrel bBar, Barrel gBar, Barrel pBar){
        this.rBar = rBar;
        this.bBar = bBar;
        this.gBar = gBar;
        this.pBar = pBar;
    }

    //decreases the health of a monkey
    public void decreaseHealth(Entity puncher){
        //makes sure monkey can't holding punch
        if(keyH.punchReleased){
        health--;
        keyH.punchReleased = false; //tells it that monkey hasn't let go
        }
    }

    //returns keyHandler so other classes can access it
    public KeyHandler getKeyH(){
        return keyH;
    }

    //finds distance from other objects for monkey when punching
    public void getDistance(String thing){
        if(thing == "red"){
            //distances from other objects
            double blueDist = Math.sqrt(Math.pow(red.getFistX() - blue.getX(), 2) + Math.pow(red.getFistY() - blue.getY(), 2));
            double greDist = Math.sqrt(Math.pow(red.getFistX() - green.getX(), 2) + Math.pow(red.getFistY() - green.getY(), 2));
            double purpDist = Math.sqrt(Math.pow(red.getFistX() - purple.getX(), 2) + Math.pow(red.getFistY() - purple.getY(), 2));
            double treeDist = Math.sqrt(Math.pow(red.getFistX() - tree.getX(), 2) + Math.pow(red.getFistY() - tree.getY(), 2));
            double rBDist =  Math.sqrt(Math.pow(red.getFistX() - rBar.getX(), 2) + Math.pow(red.getFistY() - rBar.getY(), 2));
            double bBDist =  Math.sqrt(Math.pow(red.getFistX() - bBar.getX(), 2) + Math.pow(red.getFistY() - bBar.getY(), 2));
            double gBDist =  Math.sqrt(Math.pow(red.getFistX() - gBar.getX(), 2) + Math.pow(red.getFistY() - gBar.getY(), 2));
            double pBDist =  Math.sqrt(Math.pow(red.getFistX() - pBar.getX(), 2) + Math.pow(red.getFistY() - pBar.getY(), 2));
            //checks if close enough to count as hit
            //Hitting other monkeys
            if (blueDist < punchHitBox)
            {
                blue.decreaseHealth(red);
            }
            if (greDist < punchHitBox){
                green.decreaseHealth(red);
            }
            if (purpDist < punchHitBox){
                purple.decreaseHealth(red);
            }
            if (treeDist < punchHitBox){ //hitting the tree
                red.increaseBanan();
            }
            //Hitting barrels
            if(rBDist < punchHitBox){ //hitting own barrel
                rBar.addBanan(red);
                rBar.update(rBar.barrelBanans);
            }
            if(bBDist < punchHitBox){
                bBar.addBanan(red);
                bBar.update(bBar.barrelBanans);
            }
            if(gBDist < punchHitBox){
                gBar.addBanan(red);
                gBar.update(gBar.barrelBanans);
            }
            if(pBDist < punchHitBox){
                pBar.addBanan(red);
                pBar.update(pBar.barrelBanans);
            }   
        }
        if(thing == "blue"){
            //distances from other objects
            double redDist = Math.sqrt(Math.pow(blue.getFistX() - red.getX(), 2) + Math.pow(blue.getFistY() - red.getY(), 2));
            double greDist = Math.sqrt(Math.pow(blue.getFistX() - green.getX(), 2) + Math.pow(blue.getFistY() - green.getY(), 2));
            double purpDist = Math.sqrt(Math.pow(blue.getFistX() - purple.getX(), 2) + Math.pow(blue.getFistY() - purple.getY(), 2));
            double treeDist = Math.sqrt(Math.pow(blue.getFistX() - tree.getX(), 2) + Math.pow(blue.getFistY() - tree.getY(), 2));
            double rBDist =  Math.sqrt(Math.pow(blue.getFistX() - rBar.getX(), 2) + Math.pow(blue.getFistY() - rBar.getY(), 2));
            double bBDist =  Math.sqrt(Math.pow(blue.getFistX() - bBar.getX(), 2) + Math.pow(blue.getFistY() - bBar.getY(), 2));
            double gBDist =  Math.sqrt(Math.pow(blue.getFistX() - gBar.getX(), 2) + Math.pow(blue.getFistY() - gBar.getY(), 2));
            double pBDist =  Math.sqrt(Math.pow(blue.getFistX() - pBar.getX(), 2) + Math.pow(blue.getFistY() - pBar.getY(), 2));
            //checks if close enough to count as hit
            //Hitting other monkeys
            if (redDist < punchHitBox)
                red.decreaseHealth(blue);
            if (greDist < punchHitBox)
                green.decreaseHealth(blue);
            if (purpDist < punchHitBox)
                purple.decreaseHealth(blue);
            if (treeDist < punchHitBox){//hitting the tree
                blue.increaseBanan();
            }
            //Hitting barrels
            if(rBDist < punchHitBox){
                rBar.addBanan(blue);
                rBar.update(rBar.barrelBanans);
            }
            if(bBDist < punchHitBox){ //hitting own barrel
                bBar.addBanan(blue);
                bBar.update(bBar.barrelBanans);
            }
            if(gBDist < punchHitBox){
                gBar.addBanan(blue);
                gBar.update(gBar.barrelBanans);
            }
            if(pBDist < punchHitBox){
                pBar.addBanan(blue);
                pBar.update(pBar.barrelBanans);
            }
        }
        if(thing == "green"){
            //distances from other objects
            double bluDist = Math.sqrt(Math.pow(green.getFistX() - blue.getX(), 2) + Math.pow(green.getFistY() - blue.getY(), 2));
            double redDist = Math.sqrt(Math.pow(green.getFistX() - red.getX(), 2) + Math.pow(green.getFistY() - red.getY(), 2));
            double purpDist = Math.sqrt(Math.pow(green.getFistX() - purple.getX(), 2) + Math.pow(green.getFistY() - purple.getY(), 2));
            double treeDist = Math.sqrt(Math.pow(green.getFistX() - tree.getX(), 2) + Math.pow(green.getFistY() - tree.getY(), 2));
            double rBDist =  Math.sqrt(Math.pow(green.getFistX() - rBar.getX(), 2) + Math.pow(green.getFistY() - rBar.getY(), 2));
            double bBDist =  Math.sqrt(Math.pow(green.getFistX() - bBar.getX(), 2) + Math.pow(green.getFistY() - bBar.getY(), 2));
            double gBDist =  Math.sqrt(Math.pow(green.getFistX() - gBar.getX(), 2) + Math.pow(green.getFistY() - gBar.getY(), 2));
            double pBDist =  Math.sqrt(Math.pow(green.getFistX() - pBar.getX(), 2) + Math.pow(green.getFistY() - pBar.getY(), 2));
            //checks if close enough to count as hit
            //Hitting other monkeys
            if (bluDist < punchHitBox)
                blue.decreaseHealth(green);
            if (redDist < punchHitBox)
                red.decreaseHealth(green);
            if (purpDist < punchHitBox)
                purple.decreaseHealth(green);
            if (treeDist < punchHitBox) //hitting the tree
                green.increaseBanan();
            //Hitting barrels
            if(rBDist < punchHitBox){
                rBar.addBanan(green);
                rBar.update(rBar.barrelBanans);
            }
            if(bBDist < punchHitBox){
                bBar.addBanan(green);
                bBar.update(bBar.barrelBanans);
            }
            if(gBDist < punchHitBox){ //hitting own barrel
                gBar.addBanan(green);
                gBar.update(gBar.barrelBanans);
            }
            if(pBDist < punchHitBox){
                pBar.addBanan(green);
                pBar.update(pBar.barrelBanans);
            }
        }
        if(thing == "purple"){
            //distances from other objects
            double bluDist = Math.sqrt(Math.pow(purple.getFistX() - blue.getX(), 2) + Math.pow(purple.getFistY() - blue.getY(), 2));
            double greDist = Math.sqrt(Math.pow(purple.getFistX() - green.getX(), 2) + Math.pow(purple.getFistY() - green.getY(), 2));
            double redDist = Math.sqrt(Math.pow(purple.getFistX() - red.getX(), 2) + Math.pow(purple.getFistY() - red.getY(), 2));
            double treeDist = Math.sqrt(Math.pow(purple.getFistX() - tree.getX(), 2) + Math.pow(purple.getFistY() - tree.getY(), 2));
            double rBDist =  Math.sqrt(Math.pow(purple.getFistX() - rBar.getX(), 2) + Math.pow(purple.getFistY() - rBar.getY(), 2));
            double bBDist =  Math.sqrt(Math.pow(purple.getFistX() - bBar.getX(), 2) + Math.pow(purple.getFistY() - bBar.getY(), 2));
            double gBDist =  Math.sqrt(Math.pow(purple.getFistX() - gBar.getX(), 2) + Math.pow(purple.getFistY() - gBar.getY(), 2));
            double pBDist =  Math.sqrt(Math.pow(purple.getFistX() - pBar.getX(), 2) + Math.pow(purple.getFistY() - pBar.getY(), 2));
            //checks if close enough to count as hit
            if (bluDist < punchHitBox)
                blue.decreaseHealth(purple);
            if (greDist < punchHitBox)
                green.decreaseHealth(purple);
            if (redDist < punchHitBox)
                red.decreaseHealth(purple);
            if (treeDist < punchHitBox) //hitting the tree
                purple.increaseBanan();
            if(rBDist < punchHitBox){
                rBar.addBanan(purple);
                rBar.update(rBar.barrelBanans);
            }
            if(bBDist < punchHitBox){
                bBar.addBanan(purple);
                bBar.update(bBar.barrelBanans);
            }
            if(gBDist < punchHitBox){
                gBar.addBanan(purple);
                gBar.update(gBar.barrelBanans);
            }
            if(pBDist < punchHitBox){ //hitting own barrel
                pBar.addBanan(purple);
                pBar.update(pBar.barrelBanans);
            }
        }

    }

    public int getBananCount(){
        return bananCount;
    }

    public String getColor(){
        return "";
    }

    public void setDefaultValues() {
        fistX = x+75;
        fistY = y+30;
        direction = "right";
    }

    public int getX() {
        return x + 45;
    }

    public int getY() {
        return y + 50;
    }

    public int getFistX(){
        return fistX + 26;
    }

    public int getFistY(){
        return fistY + 23;
    }

    public String getDirection(){
        return direction;
    }
}