package entity;

import main.*;

import java.awt.Graphics2D;
import javax.imageio.*;
import java.io.*;
import java.awt.image.*;

public class bMonkey extends Entity {

    GamePanel gp;
    KeyHandler keyH;

    Barrel bar;
    Entity e;

    int dieTime;

    //Constructor
    public bMonkey(GamePanel gp, KeyHandler keyH) {
        this.gp = gp;
        this.keyH = keyH;
        setDefaultValues();
        getPlayerImage();
    }

    //gets reference to own barrel
    public void setBarrel(Barrel barr) {
        bar = barr;
    }

    //Sets variables to default values on spawn
    public void setDefaultValues() {
        health = 3;
        x = 1252;
        y = 30;
        fistX = x-28;
        fistY = y+30;
        speed = 4;
        diagnoalSpeed = speed/1.3;
        bananCount = 0;
        direction = "left";
    }

    //Gets access to a reference Entity and it's methods
     public void passEntity(Entity e){
        this.e = e;
    }

    //Sets monkey's images to its pictures
    public void getPlayerImage() {
        File f1 = new File("./src/images/player/DKB_LL.png");
        File f2 = new File("./src/images/player/DKB_LR.png");
        File f3 = new File("./src/images/player/DKB_LL.png");
        File f4 = new File("./src/images/player/DKB_LR.png");
        File f5 = new File("./src/images/player/DKB_LL.png");
        File f6 = new File("./src/images/player/DKB_LR.png");
        File f7 = new File("./src/images/player/DKB_RL.png");
        File f8 = new File("./src/images/player/DKB_RR.png");

        try {
            up1 = ImageIO.read(f1);
            up2 = ImageIO.read(f2);
            down1 = ImageIO.read(f3);
            down2 = ImageIO.read(f4);
            left1 = ImageIO.read(f5);
            left2 = ImageIO.read(f6);
            right1 = ImageIO.read(f7);
            right2 = ImageIO.read(f8);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    //Updates monkey's position and sprite if movement keys are pressed
    public void update() {
        //If monkey is dead, revives it 10 seconds later
         if(checkDead()){
             if(dieTime <= gp.getTime()-10){
                setDefaultValues();
             }
        }
        //If monkey is alive and movement key is pressed, check which keys and move
        else if (keyH.upPressed == true || keyH.downPressed == true
                || keyH.leftPressed == true || keyH.rightPressed == true) {

            if((keyH.upPressed == true && keyH.leftPressed == true) && ( y > -8 && x > 438)){
                direction = "left";
                fistX = x-28;
                fistY = y+30;
                y -= diagnoalSpeed;
                x -= diagnoalSpeed;
            }
            else if((keyH.upPressed == true && keyH.rightPressed == true) && (y > -8 && x < 1370)){
                direction = "right";
                fistX = x+75;
                fistY = y+30;
                y -= diagnoalSpeed;
                x += diagnoalSpeed;
            }
            else if((keyH.downPressed == true && keyH.leftPressed == true) && (y < 920 && x > 438)){
                direction = "left";
                fistX = x-28;
                fistY = y+30;
                y += diagnoalSpeed;
                x -= diagnoalSpeed;
            }
            else if((keyH.downPressed == true && keyH.rightPressed == true) && (y < 920 && x < 1370)){
                direction = "right";
                fistX = x+75;
                fistY = y+30;
                y += diagnoalSpeed;
                x += diagnoalSpeed;
            }
            else if (keyH.upPressed == true && y > -8) {
                direction = "up";
                fistX = x+30;
                fistY = y-40;
                y -= speed;
            } else if (keyH.downPressed == true && y < 920) {
                direction = "down";
                fistX = x+30;
                fistY = y+85;
                y += speed;
            } else if (keyH.leftPressed == true && x > 438) {
                direction = "left";
                fistX = x-28;
                fistY = y+30;
                x -= speed;
            } else if (keyH.rightPressed == true && x < 1370) {
                direction = "right";
                fistX = x+75;
                fistY = y+30;
                x += speed;
            }
            //Updates sprite between direction1 and direction2
            spriteCounter++;
            if (spriteCounter > 10) {
                if (spriteNum == 1) {
                    spriteNum = 2;
                } else if (spriteNum == 2) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
        }
        //If punching key is pressed, runs getDistance with it's own color
        if(keyH.punchPressed == true && !checkDead()){
            e.getDistance("blue");
        }
    }
    
    //Draws the monkeys fist when punching
    public void drawFist(Graphics2D gRMFist){
        if (!checkDead()){
        File f1 = new File("./src/images/player/fistUp.png");
        File f2 = new File("./src/images/player/fistDown.png");
        File f3 = new File("./src/images/player/fistLeft.png");
        File f4 = new File("./src/images/player/fistRight.png");
        try{
        upFist = ImageIO.read(f1);
        downFist = ImageIO.read(f2);
        leftFist = ImageIO.read(f3);
        rightFist = ImageIO.read(f4);
        }catch(IOException e){
            e.printStackTrace();}
        switch(direction){
           case "up":
                image = upFist; 
                gRMFist.drawImage(image, fistX, fistY, gp.tileSize, gp.tileSize, null);
            break;
            case "down":
                image = downFist; 
                gRMFist.drawImage(image, fistX, fistY, gp.tileSize, gp.tileSize, null);
            break;
            case "left":
                image = leftFist; 
                gRMFist.drawImage(image, fistX, fistY, gp.tileSize, gp.tileSize, null);
                //pass fistX and fistY to distance formula
            break;
            case "right":
                image = rightFist; 
                gRMFist.drawImage(image, fistX, fistY, gp.tileSize, gp.tileSize, null);
            break;
            default:
                image = null;
                gRMFist.drawImage(image, x, y, gp.tileSize, gp.tileSize, null);
            break;
        }
    }
    }

    //Draws the monkey on the world
    public void draw(Graphics2D gBMonkey) {

        BufferedImage image = null;
        //If monkey is dead, draw as dead monkey
        if(checkDead()){
            File dead = new File("./src/images/player/grave.png");
            try{
                BufferedImage deadMonkey = ImageIO.read(dead);
                image = deadMonkey;
            }catch(IOException e){
                e.printStackTrace();
            }
        }
        else{ //If monkey is alive, chooses sprite based on direction facing
        switch (direction) {
            case "up":
                if (spriteNum == 1) {
                    image = up1;
                }
                if (spriteNum == 2) {
                    image = up2;
                }
                break;
            case "down":
                if (spriteNum == 1) {
                    image = down1;
                }
                if (spriteNum == 2) {
                    image = down2;
                }
                break;
            case "left":
                if (spriteNum == 1) {
                    image = left1;
                }
                if (spriteNum == 2) {
                    image = left2;
                }
                break;
            case "right":
                if (spriteNum == 1) {
                    image = right1;
                }
                if (spriteNum == 2) {
                    image = right2;
                }
                break;
        }
            
        }
        gBMonkey.drawImage(image, x, y, gp.tileSize * 2, gp.tileSize * 2, null);
    }
    
    //Returns the monkey's health as a string
    public String getHealth() {
        switch (health) {
            case 3:
                return "blue3";
            case 2:
                return "blue2";
            case 1:
                return "blue1";
            default:
                return "empty";
        }
    }

    //Increases monkey's banans by one
    public void addBanan() {
        bananCount++;
    }

    //Decreases monkey's health by one
    public void decreaseHealth(Entity puncher){
         if(health > 0){
            if(puncher.getKeyH().punchReleased){
            health--;
            puncher.getKeyH().punchReleased = false;
            if(health == 0){ //If monkey gets killed
                checkDead(); //Sets as dead
                puncher.bananCount += bananCount; //Gives all of banans to killer
                bananCount = 0; //Sets bananCount to 0
                dieTime = gp.getTime();
        }
        }
        }
    }

    public void respawn(){
        setDefaultValues();
    }

    //Checks to see if monkey is dead
    public boolean checkDead(){
        if(health == 0){
            return true;
        }
        return false;
    }

    //Returns monkey's KeyHandler reference
    public KeyHandler getKeyH(){
        return keyH;
    }

    //
    public void increaseBanan(){
        if(keyH.punchReleased){
            bananCount++;
            keyH.punchReleased = false;
        }
    }
    
    //Returns color of monkey as a String
    public String getColor(){
        return "blue";
    }

    public String drawBananCount(){
        return "" + bananCount;
    }
}
