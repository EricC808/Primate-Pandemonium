package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.*;
import java.awt.event.*;

import entity.*;

import javax.swing.JPanel;

public class GamePanel extends JPanel implements Runnable {
    // SCREEN SETTINGS
    final int originalTileSize = 16; // 16 x 16 tile
    final int scale = 3;

    //Tiles
    public final int tileSize = originalTileSize * scale;
    final int maxScreenCol = 16;
    final int maxScreenRow = 12;
    final int screenWidth = tileSize * maxScreenCol;
    final int screenHeight = tileSize * maxScreenRow;

    // FPS
    int FPS = 60;
    int countRed = 2;
    int countBlue = 2;
    int countGreen = 2;
    int countPurple = 2;

    //Monkey Keys
    KeyHandler keyH = new KeyHandler();
    KeyHandler keyHR = new KeyHandler(KeyEvent.VK_W, KeyEvent.VK_S, KeyEvent.VK_A, KeyEvent.VK_D, KeyEvent.VK_E);
    KeyHandler keyHB = new KeyHandler(KeyEvent.VK_I, KeyEvent.VK_K, KeyEvent.VK_J, KeyEvent.VK_L, KeyEvent.VK_O);
    KeyHandler keyHP = new KeyHandler(KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_CONTROL);
    KeyHandler keyHG = new KeyHandler(KeyEvent.VK_NUMPAD5, KeyEvent.VK_NUMPAD2, KeyEvent.VK_NUMPAD1,
            KeyEvent.VK_NUMPAD3, KeyEvent.VK_NUMPAD6);

    //Gamethread
    Thread gameThread;


    //Monkeys
    rMonkey redMonkey = new rMonkey(this, keyHR);
    bMonkey bluMonkey = new bMonkey(this, keyHB);
    gMonkey greMonkey = new gMonkey(this, keyHG);
    pMonkey purpMonkey = new pMonkey(this, keyHP);
    Entity entity = new Entity();

    //Background
    backgroundLoader loadBackground = new backgroundLoader(this);
    StartMenuLoader startMenu = new StartMenuLoader(this, keyH, "");
    
    //Hearts
    Heart redHeart = new Heart(this, 347, 0);
    Heart bluHeart = new Heart(this, 1458, 0);
    Heart greHeart = new Heart(this, 1458, 925);
    Heart purHeart = new Heart(this, 347, 925);
    
    //Barrels
    Barrel redBarrel = new Barrel(this, 500, 50, redMonkey, keyHR); // top left
    Barrel bluBarrel = new Barrel(this, 1330, 50, bluMonkey, keyHB); // top right
    Barrel greBarrel = new Barrel(this, 1330, 875, greMonkey, keyHG); // bottom right
    Barrel purBarrel = new Barrel(this, 500, 875, purpMonkey, keyHP); // bottom left

    //Banana Tree
    BananTree tree = new BananTree(this, 834, 300);

    //Booleans
    boolean backgroundLoaded = true, started = false, controlsRead = false;

    //Images
    Image playerImg, background;

    //Timer
    int x = tileSize*18;
    int y = tileSize/5;
    int width = screenWidth - (tileSize*12);
    int height = tileSize;
    Font stringFont = new Font( "SansSerif", Font.PLAIN, 30);
    int time = 100;
    String timey = "";
    String winner = "";
    boolean overTime = false;

    public GamePanel() {
        //Constructing basic values
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.addKeyListener(keyHR);
        this.addKeyListener(keyHB);
        this.addKeyListener(keyHG);
        this.addKeyListener(keyHP);
        this.setFocusable(true);
        //Passing references to Entity
        entity.getMonkeys(redMonkey, bluMonkey, greMonkey, purpMonkey);
        entity.getKeyHandler(keyH);
        entity.getBananTree(tree);
        entity.getBarrel(redBarrel, bluBarrel, greBarrel, purBarrel);
        //Passing references to Monkeys
        redMonkey.passEntity(entity);
        bluMonkey.passEntity(entity);
        greMonkey.passEntity(entity);
        purpMonkey.passEntity(entity);
        repaint();
        //Set barrels to monkeys
        initializeMonkeys();
        initializeBarrels();
    }

    //Starts game
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void initializeMonkeys(){
        redMonkey.setDefaultValues();
        bluMonkey.setDefaultValues();
        greMonkey.setDefaultValues();
        purpMonkey.setDefaultValues();
    }

    //Assigns monkeys to their barrels
    public void initializeBarrels() {
        redMonkey.setBarrel(redBarrel);
        bluMonkey.setBarrel(bluBarrel);
        greMonkey.setBarrel(greBarrel);
        purpMonkey.setBarrel(purBarrel);
        redBarrel.setDefaultValues();
        bluBarrel.setDefaultValues();
        greBarrel.setDefaultValues();
        purBarrel.setDefaultValues();
    }

    //Runs the game
    @Override
    public void run() {

        double drawInterval = 1000000000 / FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;

        
        while (gameThread != null) {
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if (delta >= 1) {
                update();
                repaint();
                delta--;
            }

            if (timer >= 1000000000) {
                timer = 0;
            }
        }
    }
    public int getTime(){
        return (int)startMenu.elapsedSeconds;
    }

    public void restartTimer()
        {time = 100;}
    
    //Displays timer at the top of game, ends game when at 0
    public void drawTimer(Graphics2D gTimer, int x, int y, int width, int height){
        Color c = new Color(0,0,0); //black
        gTimer.setColor(c);  
        gTimer.fillRoundRect(x, y, width, height, 35, 35);
        
        c = new Color (255, 255, 255); //white
        gTimer.setColor(c);
        gTimer.setStroke(new BasicStroke(5));
        gTimer.drawRoundRect(x+5, y+5, width-10, height-10, 25, 25);
        gTimer.setFont(gTimer.getFont().deriveFont(Font.PLAIN,32));
        Barrel winner = checkWinner();
        if (startMenu.Fullsec <= 0 && startMenu.Fullmin <= 0 && winner != null)
            overTime = true;
        timey = startMenu.getTime();
        gTimer.setFont(stringFont);
        if (startMenu.Fullsec <= 0 && startMenu.Fullmin <= 0){
            gTimer.drawString("OVERTIME", x + 20, y + 35);
            checkWinner();

    }
        else
            gTimer.drawString(timey, x + 55, y + 35);
    }

    //Calls update methods for monkeys and hearts
    public void update() {
        //Monkey updates
        bluMonkey.update();
        purpMonkey.update();
        greMonkey.update();
        redMonkey.update();
        //Hearts updates
        redHeart.update(redMonkey.getHealth());
        bluHeart.update(bluMonkey.getHealth());
        greHeart.update(greMonkey.getHealth());
        purHeart.update(purpMonkey.getHealth());
    }
    
    //Draws the sprites
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if(started != true){ //If round has not yet started
        Graphics2D gMenu = (Graphics2D) g;
        startMenu.draw(gMenu); //Shows startment
        started = startMenu.checkStart(); //change to switch statement for endscreens
        }else if (started == true && controlsRead == false)
        {
        Graphics2D gControls = (Graphics2D) g;
        startMenu.loadControls();
        startMenu.draw(gControls);
        controlsRead = startMenu.checkControls();
        }else{ //If round has started
            
            //Load background first
            Graphics2D gBackground = (Graphics2D) g;
            loadBackground.draw(gBackground);

           

            // MONKEYS
            Graphics2D gRMonkey = (Graphics2D) g;
            redMonkey.draw(gRMonkey);
            Graphics2D gBMonkey = (Graphics2D) g;
            bluMonkey.draw(gBMonkey);
            Graphics2D gGMonkey = (Graphics2D) g;
            greMonkey.draw(gGMonkey);
            Graphics2D gPMonkey = (Graphics2D) g;
            purpMonkey.draw(gPMonkey);

            
            // HEARTS
            Graphics2D gRHeart = (Graphics2D) g;
            redHeart.draw(gRHeart);
            Graphics2D gBHeart = (Graphics2D) g;
            bluHeart.draw(gBHeart);
            Graphics2D gGHeart = (Graphics2D) g;
            greHeart.draw(gGHeart);
            Graphics2D gPHeart = (Graphics2D) g;
            purHeart.draw(gPHeart);

            // BARRELS
            Graphics2D gRBarrel = (Graphics2D) g;
            redBarrel.draw(gRBarrel);
            Graphics2D gBBarrel = (Graphics2D) g;
            bluBarrel.draw(gBBarrel);
            Graphics2D gGBarrel = (Graphics2D) g;
            greBarrel.draw(gGBarrel);
            Graphics2D gPBarrel = (Graphics2D) g;
            purBarrel.draw(gPBarrel);

            // TIMER
            Graphics2D gTimer = (Graphics2D) g;
            drawTimer(gTimer, x, y, width, height);

            // TREE
            Graphics2D gBananTree = (Graphics2D) g;
            tree.draw(gBananTree);

            // BANANS HELD
            Color bananColor = new Color(255,255,0);
            Graphics2D gRBanan = (Graphics2D) g;
            gRBanan.setColor(bananColor);
            gRBanan.setFont(gRBanan.getFont().deriveFont(Font.ITALIC,50));
            gRBanan.drawString("x" + redMonkey.drawBananCount(), 358, 130);
            
            Graphics2D gBBanan = (Graphics2D) g;
            gBBanan.setColor(bananColor);
            gBBanan.setFont(gBBanan.getFont().deriveFont(Font.ITALIC,50));
            gBBanan.drawString("x" +bluMonkey.drawBananCount(), 1470, 130);

            Graphics2D gGBanan = (Graphics2D) g;
            gGBanan.setColor(bananColor);
            gGBanan.setFont(gGBanan.getFont().deriveFont(Font.ITALIC,50));
            gGBanan.drawString("x" + greMonkey.drawBananCount(), 1470, 930);

            Graphics2D gPBanan = (Graphics2D) g;
            gPBanan.setColor(bananColor);
            gPBanan.setFont(gPBanan.getFont().deriveFont(Font.ITALIC,50));
            gPBanan.drawString("x" + purpMonkey.drawBananCount(), 358, 930);

 
            //FISTS
            if (keyHR.punchPressed)
            {
                countRed = 0; //Resets count upon new press
            }
            while(countRed <= 1){ //Makes punch sprite flash rather than stay showing
            Graphics2D gRMFist = (Graphics2D) g;
            redMonkey.drawFist(gRMFist);
            countRed++;
            }
            
            if(keyHB.punchPressed){
                countBlue = 0;
            }
            while(countBlue <= 1){
            Graphics2D gBMFist = (Graphics2D) g;
            bluMonkey.drawFist(gBMFist);
            countBlue++;
            }

            if (keyHG.punchPressed){
                countGreen = 0;
            }
            while (countGreen <= 1)
            {
            Graphics2D gGMFist = (Graphics2D) g;
            greMonkey.drawFist(gGMFist);
            countGreen++;
            }
            
            if(keyHP.punchPressed){
                countPurple = 0;
            } 
            while(countPurple <=1){
            Graphics2D gPMFist = (Graphics2D) g;
            purpMonkey.drawFist(gPMFist);
            countPurple++;
            }
            g.dispose();
        }
    }

    public Barrel checkWinner(){
        int highestBanans = 0;
        Barrel winner = null;
        Barrel[] barrelList = new Barrel[4];
        barrelList[0] = redBarrel;
        barrelList[1] = bluBarrel;
        barrelList[2] = greBarrel;
        barrelList[3] = purBarrel;
        for(int i = 0; i<4; i++){
            if(barrelList[i].getBanans() > highestBanans){
                highestBanans = barrelList[i].getBanans();
                winner = barrelList[i];
            }
        }
        if(winner != null){
            overTime = false;
        }
        return winner;
    }
}