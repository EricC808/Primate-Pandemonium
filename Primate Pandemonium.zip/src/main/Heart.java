package main;

import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;
public class Heart
{
    GamePanel gp;
    public BufferedImage heartPrint;
    public int myX, myY;
    String color;

    public Heart(GamePanel gp, int x, int y) 
    {
        this.gp = gp;
        myX = x;
        myY = y;
        color = "";
        getImage();
    }

    //Gets heart image based on color and health
    public void getImage()
    {
        switch(color){
            //red start
            case "red3":
            File r3HeartImage = new File("./src/images/hearts/redHeart.png");
            try{
            heartPrint = ImageIO.read(r3HeartImage);
            }catch(IOException e){
            e.printStackTrace();
            }
            break;
            
            case "red2":
            File r2HeartImage = new File("./src/images/hearts/redHeart_twoThird.png");
            try{
            heartPrint = ImageIO.read(r2HeartImage);
            }catch(IOException e){
            e.printStackTrace();
            }
            break;

            case "red1":
            File r1HeartImage = new File("./src/images/hearts/redHeart_oneThird.png");
            try{
            heartPrint = ImageIO.read(r1HeartImage);
            }catch(IOException e){
            e.printStackTrace();
            }
            break;
            //red end

            //blue start
            case "blue3":
            File b3HeartImage = new File("./src/images/hearts/blueHeart.png");
            try{
            heartPrint = ImageIO.read(b3HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;
            
            case "blue2":
            File b2HeartImage = new File("./src/images/hearts/blueHeart_twoThird.png");
            try{
            heartPrint = ImageIO.read(b2HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;

            case "blue1":
            File b1HeartImage = new File("./src/images/hearts/blueHeart_oneThird.png");
            try{
            heartPrint = ImageIO.read(b1HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;
            //blue end

            case "green3":
            File g3HeartImage = new File("./src/images/hearts/greenHeart.png");
            try{
            heartPrint = ImageIO.read(g3HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;
            
            case "green2":
            File g2HeartImage = new File("./src/images/hearts/greenHeart_twoThird.png");
            try{
            heartPrint = ImageIO.read(g2HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;

            case "green1":
            File g1HeartImage = new File("./src/images/hearts/greenHeart_oneThird.png");
            try{
            heartPrint = ImageIO.read(g1HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;
            //green end

            //purple start
            case "purple3":
            File p3HeartImage = new File("./src/images/hearts/purpleHeart.png");
            try{
            heartPrint = ImageIO.read(p3HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;
            
            case "purple2":
            File p2HeartImage = new File("./src/images/hearts/purpleHeart_twoThird.png");
            try{
            heartPrint = ImageIO.read(p2HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;

            case "purple1":
            File p1HeartImage = new File("./src/images/hearts/purpleHeart_oneThird.png");
            try{
            heartPrint = ImageIO.read(p1HeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;

            default:
            File eHeartImage = new File("./src/images/hearts/emptyHeart.png");
            try{
            heartPrint = ImageIO.read(eHeartImage);
            }catch(IOException e){e.printStackTrace();
            }
            break;
            }
    }
    //Updates image used based on health passed in
    public void update(String health){
        color = health;
        getImage();
    }

    //Draws the heart image
    public void draw(Graphics2D gHeart)
    {
        getImage();
        BufferedImage image = null;
        image = heartPrint;
        gHeart.drawImage(image, myX, myY, gp.tileSize*2, gp.tileSize*2, null);
    }

}
