package main;

import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;

public class backgroundLoader {
    GamePanel gp;
    public BufferedImage backgroundImage; //image used for the background
    public int x, y;

    public backgroundLoader(GamePanel gp) {
        this.gp = gp;
        setDefaultValues();
        getBackgroundImage();
    }

    //Sets default coordinates and images
    public void setDefaultValues() {
        x = 200;
        y = 200;
        backgroundImage = null;
    }

    //Gets the image used for background
    public void getBackgroundImage() {
        File backgroundFile = new File("./src/images/background/background.jpg");
        try {
            backgroundImage = ImageIO.read(backgroundFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Draws the background image
    public void draw(Graphics2D g2) {
        BufferedImage image = null;
        image = backgroundImage;
        g2.drawImage(image, 447, 0, gp.tileSize * 21, gp.tileSize * 21, null);
    }
}
