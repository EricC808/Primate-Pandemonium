package main;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener{

    public boolean creditsPressed, spacePressed;
    public boolean upPressed, downPressed, leftPressed, rightPressed, enterPressed, punchPressed, punchReleased = true; //punchReleased defaults to true to allow punching upon first press
    int up, left, right, down, punch;

    //Sets values based on individual parameters
    public KeyHandler(int myUp, int myDown, int myLeft, int myRight, int punchKey){
        up = myUp;
        down = myDown;
        left = myLeft;
        right= myRight;
        punch = punchKey;
    }

    public KeyHandler(){}

    //Checks to see if keys are being pressed
	@Override
	public void keyPressed(KeyEvent e) {
        
        int code = e.getKeyCode();

        if(code == up)
            upPressed = true;
        if(code == down)
            downPressed = true;
        if(code == left)
            leftPressed = true;
        if(code == right)
            rightPressed = true;
        if(code == punch)
            punchPressed = true;
        if(code == KeyEvent.VK_ENTER)
            enterPressed = true;
        if(code == KeyEvent.VK_C)
            creditsPressed = true;
        if(code == KeyEvent.VK_SPACE)
            spacePressed = true;
	}
    //Checks to see if keys are released
	@Override
	public void keyReleased(KeyEvent e) {
         
        int code = e.getKeyCode();

        if(code == up)
            upPressed = false;
        if(code == down)
            downPressed = false;
        if(code == left)
            leftPressed = false;
        if(code == right)
            rightPressed = false;
        if(code == punch){
            punchPressed = false;
            punchReleased = true; //When punch released, sets to true
        }
        if(code == KeyEvent.VK_C)
            creditsPressed = false;
        if(code == KeyEvent.VK_SPACE)
            spacePressed = false;
	}

    //Override to do nothinf
	@Override
	public void keyTyped(KeyEvent e) {

	}
}