package main;

import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;

public class StartMenuLoader {
    double elapsedSeconds;
    String zero = "";
    double startTime;
    int Fullmin = 9999, Fullsec = 9999;

    GamePanel gp;
    public BufferedImage backgroundImage, controlsImage;
    public int x, y;
    KeyHandler keyH;
    boolean check = true;

    public StartMenuLoader(GamePanel gp, KeyHandler keyH, String w) {
        this.gp = gp;
        this.keyH = keyH;
        String winner = w;
        getBackgroundImage(winner);
    }

    //Gets startMenu image
    public void getBackgroundImage(String winner) {
        switch(winner){
            case "red":
                File redWinner = new File("./src/images/background/endScreenRed.png");
                try {
                backgroundImage = ImageIO.read(redWinner);
                } catch (IOException e) {
                e.printStackTrace();
                }
                break;
                
                case "blue":
                File blueWinner = new File("./src/images/background/endScreenBlue.png");
                try {
                backgroundImage = ImageIO.read(blueWinner);
                } catch (IOException e) {
                e.printStackTrace();
                }
                break;
                
                case "green":
                File greenWinner = new File("./src/images/background/endScreenGreen.png");
                try {
                backgroundImage = ImageIO.read(greenWinner);
                } catch (IOException e) {
                e.printStackTrace();
                }
                break;
                
                case "purple":
                File purpleWinner = new File("./src/images/background/endScreenPurple.png");
                try {
                backgroundImage = ImageIO.read(purpleWinner);
                } catch (IOException e) {
                e.printStackTrace();
                }
                break;
                
                default :
                File backgroundFile = new File("./src/images/background/titleScreen.png");
                try {
                backgroundImage = ImageIO.read(backgroundFile);
                } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //Checks to see if round has started
    public boolean checkStart(){
        if(keyH.enterPressed){
            if(gp.controlsRead){
                gp.restartTimer();
                gp.initializeMonkeys();
                gp.initializeBarrels();
            }
            startTime = System.currentTimeMillis();
            check = false;
            keyH.enterPressed = false;
            return true;
        }
        if (keyH.creditsPressed) { // When C pressed it opens up the credits
            loadCredits();
            keyH.creditsPressed = false;
        }
        return false;
    }

    public String getTime()
    {
        double elapsedTime = System.currentTimeMillis() - startTime;
        elapsedSeconds = elapsedTime / 1000;
        int secondsDisplay = (int)elapsedSeconds % 60;
        int elapsedMinutes = (int)elapsedSeconds / 60;
        Fullmin = (int)(gp.time/60 - (int)elapsedMinutes);
        Fullsec = (int)(gp.time - secondsDisplay - 41);
        if (Fullsec <= 0 && Fullmin <= 0 && gp.checkWinner() != null)
        {
            gp.winner = gp.checkWinner().getColor(); //returns winners color
            getBackgroundImage(gp.winner);
            gp.started = false;
        }
        
        if (Fullsec < 10)
            zero = "0";
        else
            zero = "";

        return "0" + Fullmin + ":" + zero + Fullsec;
    }

    //Draws the start menu image
    public void draw(Graphics2D g2) {
        BufferedImage image = null;
        image = backgroundImage;
        g2.drawImage(image, 447, 0, gp.tileSize * 21, gp.tileSize * 21, null);
    }

    public void loadControls(){
        
        File controlsFile = new File("./src/images/background/controls.png");
        try {
        backgroundImage = ImageIO.read(controlsFile);
        } catch (IOException e) {
        e.printStackTrace();
        }
        if(keyH.spacePressed)
        {
            gp.controlsRead = true;
        }
    
    }

    public boolean checkControls(){
        if(keyH.spacePressed){
            startTime = System.currentTimeMillis();
            //Sets values to beginning
            gp.restartTimer();
            gp.initializeMonkeys();
            gp.initializeBarrels();
            keyH.spacePressed = false;
            return true;
        }
        return false;
    }

    // loads the credits for the game
    public void loadCredits() {
        final JTextArea edit = new JTextArea(10, 60);
        edit.setText("Credits:\n\n- Original Donkey Kong Sprite: https://www.pinterest.com/pin/757871443542234720/");
        edit.append(
                "\n\n- Pixel Heart: https://freesvg.org/pixel-heart \n\n- Grass Background: https://www.artstation.com/artwork/EaKzle ");
        edit.append(
                "\n\n- Tree: FPixelArt%2Fcomments%2Fej9kwp%2Fjust_your_regular_pixel_palm_tree%2F&psig=AOvVaw0bmnx0lTP_tueTpIwZSezY&ust=1683747127794000&source=images&cd=vfe&ved=0CBIQjhxqFwoTCIigoIT96P4CFQAAAAAdAAAAABAI ");
        edit.append(
                "\n\n- Banana: https://www.nicepng.com/ourpic/u2q8y3u2o0y3t4y3_pixel-clipart-banana-banana-pixel-art-png/ \n\n- Title Screen Background: https://wallpaperaccess.com/pixel-forest ");
        edit.append(
                "\n\n- Gorilla Tag Menu Button: https://thecodex.fandom.com/wiki/Gorilla_(Gorilla_Tag) \n\n- Fist: https://www.pixilart.com/draw/fist-b945cc6be5 ");
        edit.append(
                "\n\n- Code for setting up GamePanel (first 4 videos): https://www.youtube.com/watch?v=om59cwR7psI&list=PL_QPQmz5C6WUF-pOQDsbsKbaBZqXj4qSq ");

        JFrame frame = new JFrame("Credits");
        frame.getContentPane().add(new JScrollPane(edit), BorderLayout.NORTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
