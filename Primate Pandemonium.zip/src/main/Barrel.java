package main;

import entity.*;
import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;

public class Barrel {
    GamePanel gp;
    public BufferedImage barrelPrint;
    public int myX, myY, count;
    public int barrelBanans;
    String barrelType;
    Entity owner;
    KeyHandler keyH;

    //Barrel constrcutor
    public Barrel(GamePanel gp, int x, int y, Entity owner, KeyHandler keyH) {
        this.gp = gp;
        myX = x;
        myY = y;
        count = 0;
        barrelType = "";
        this.owner = owner; //Monkey that barrel is assigned to
        this.keyH = keyH;
        getImage();
    }

    public void setDefaultValues(){
        barrelBanans = 0;
        barrelType = "";
        count = 0;
    }

    //Gets Barrel image to use
    public void getImage() {
        switch (barrelType) {
            case "full": //When barrel is full
                File fullBarrelImage = new File("./src/images/barrels/barrelFull.png");
                try {
                    barrelPrint = ImageIO.read(fullBarrelImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;

            case "half": //When barrel is half full
                File halfBarrelImage = new File("./src/images/barrels/barrelHalf.png");
                try {
                    barrelPrint = ImageIO.read(halfBarrelImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;

            case "some": //When barrel has some banans
                File someBarrelImage = new File("./src/images/barrels/barrelSome.png");
                try {
                    barrelPrint = ImageIO.read(someBarrelImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;

            default: //When barrel is empty
                File eBarrelImage = new File("./src/images/barrels/barrelEmpty.png");
                try {
                    barrelPrint = ImageIO.read(eBarrelImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    //Updates barrel's type depending on banan count
    public void update(int bananCount) {
        count = bananCount;
        if (count > 20) {
            barrelType = "full";
        } else if (count > 10) {
            barrelType = "half";
        } else if (count > 0) {
            barrelType = "some";
        } else {
            barrelType = "empty";
        }
    }

    //Decides behavior of barrel based on monkey hitting
    public void addBanan(Entity monkey){
        if(monkey.getKeyH().punchReleased){ //makes sure monkey isn't holding down punch
            if (owner == monkey){ //if barrel is your own barrel
                if (monkey.bananCount > 0){ //checks to see if monkey has banans
                    monkey.bananCount--;
                    barrelBanans++;
                    gp.overTime = false;
                    monkey.getKeyH().punchReleased = false;
                }
            }else{ //barrel is not monkey's barrel
                if (barrelBanans > 0){ //checks to see if barrel has banans
                    monkey.bananCount++;
                    barrelBanans--;
                    monkey.getKeyH().punchReleased = false;          }
            }  
        }
    }

    //Draws the barrel image
    public void draw(Graphics2D gBarrel) {
        getImage();
        BufferedImage image = null;
        image = barrelPrint;
        gBarrel.drawImage(image, myX, myY, gp.tileSize * 2, gp.tileSize * 2, null);
    }

    //Returns x-coordinate of center of Barrel
    public int getX(){
        return myX + 32; //Shift 32 pixels to the right
    }

    //Returns y-coordinate of center of Barrel
    public int getY(){
        return myY + 40; //Shift 40 pixels down
    }

    public int getBanans(){
        return barrelBanans;
    }

    public String getColor(){
        return owner.getColor();
    }
}
