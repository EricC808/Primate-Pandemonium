package main;


import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;

public class BananTree {
    GamePanel gp;
    public BufferedImage bananTreePrint;
    public int myX, myY, count;
    String barrelType;

    //Constructor to pass in gamepanel and spawn coordinates
    public BananTree(GamePanel gp, int x, int y) {
        this.gp = gp;
        myX = x;
        myY = y;
        count = 0;
        getImage();
    }

    //Empty constructor
    public BananTree(){}

    //Gets BananTree image
    public void getImage() {
        File BananTreeImage = new File("./src/images/background/bananTreeFull.png");
        try {
            bananTreePrint = ImageIO.read(BananTreeImage);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Draws BananTree
    public void draw(Graphics2D gBananTree) {
        getImage();
        BufferedImage image = null;
        image = bananTreePrint;
        gBananTree.drawImage(image, myX, myY, gp.tileSize * 5, gp.tileSize * 5, null);
    }

    //Returns x-coordinate of center of BananTree
    public int getX(){
        return myX + 116; //shift 116 pixels to the right
    }
    
    //Returns y-coordinate of center of BananTree
    public int getY(){
        return myY + 210; //shift 210 pixels down
    }
}
