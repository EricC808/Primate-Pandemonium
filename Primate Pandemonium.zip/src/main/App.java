package main;
import javax.swing.JFrame;

public class App
{
   public static void main(String[] args)
   {
       JFrame window = new JFrame();
       window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       window.setTitle("Primate Pandemonioum");
       

       GamePanel monkeyPanel = new GamePanel();
       window.add(monkeyPanel);


       window.pack();

       window.setLocationRelativeTo(null);
       window.setVisible(true);

       monkeyPanel.startGameThread();
     
   }
}

// REMAINING TASKS
// Barrel Sprites
// Winner Sprites
// Game doesn't restart if there is no winner